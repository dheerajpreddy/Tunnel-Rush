Tunnel Rush
=========================
Dheeraj Reddy Pailla, 20161053

Controls:
1. Up arrow key to jump
2. Left arrow key to rotate left
3. Right arrow key to rotate right
4. R for Rick Sanchez mode
5. G for greyscale

BONUS:
1. Press R for Rick Sanchez level
2. 5 levels, with 5th level changing the environment


License
-------
The MIT License

Copyright &copy; 2018 Dheeraj Reddy Pailla <dheerajpreddy@gmail.com>
